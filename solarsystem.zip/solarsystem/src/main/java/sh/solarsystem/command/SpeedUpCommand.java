package sh.solarsystem.command;

import sh.solarsystem.controller.SolarSystemController;

/**
 * Speed up button
 */
public class SpeedUpCommand implements Command {

    private final SolarSystemController controller;
    
    public SpeedUpCommand(SolarSystemController controller) {
        this.controller = controller;
    }

    /**
     * Does the speed up action
     */
    @Override
    public void execute() {
        controller.speedUp();
    }
}
