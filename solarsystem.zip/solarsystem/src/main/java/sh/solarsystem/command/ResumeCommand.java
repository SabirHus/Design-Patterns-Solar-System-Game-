package sh.solarsystem.command;

import sh.solarsystem.controller.SolarSystemController;

/**
 * Resume button 
 */
public class ResumeCommand implements Command {

    private final SolarSystemController controller;

    public ResumeCommand(SolarSystemController controller) {
        this.controller = controller;
    }

    /**
     * Executes the resume command
     */
    @Override
    public void execute() {
        controller.resume();
    }
}
