package sh.solarsystem.command;

import sh.solarsystem.controller.SolarSystemController;

/**
 * Pause button
 */
public class PauseCommand implements Command {

    private final SolarSystemController controller;

    public PauseCommand(SolarSystemController controller) {
        this.controller = controller;
    }

    /**
     * Does the pause action
     */
    @Override
    public void execute() {
        controller.pause();
    }
}
