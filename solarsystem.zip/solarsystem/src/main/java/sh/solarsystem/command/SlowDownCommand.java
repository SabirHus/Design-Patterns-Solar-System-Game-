package sh.solarsystem.command;

import sh.solarsystem.controller.SolarSystemController;

/**
 * Slow down action
 */
public class SlowDownCommand implements Command {

    private final SolarSystemController controller;

    public SlowDownCommand(SolarSystemController controller) {
        this.controller = controller;
    }

    /**
     * Executes the slow down command
     */
    @Override
    public void execute() {
        controller.slowDown();
    }
}
