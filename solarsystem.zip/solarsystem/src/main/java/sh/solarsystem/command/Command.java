package sh.solarsystem.command;

/**
 * Main command class
 */
public interface Command {
    void execute();
}
