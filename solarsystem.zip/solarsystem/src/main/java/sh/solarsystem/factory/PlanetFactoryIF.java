package sh.solarsystem.factory;

import sh.solarsystem.model.Planet;

/**
 * Interface for making planets
 * Makes sure they all follow the same contract
 */
	public interface PlanetFactoryIF {

  /**
   * Makes a planet based on type
   */
    Planet createPlanet(String type);
}
