package sh.solarsystem.view;

import javafx.scene.control.Label;

/**
 * Displays how many planets have been visited
 */
public class ScoreLabel extends Label {

    private int visitedCount = 0;

    /**
     * Makes the score label and starts with 0
     */
    public ScoreLabel() {
        super("Visited: 0");
        setLayoutX(10);
        setLayoutY(70);
        setStyle("-fx-text-fill: white;");
    }

    /**
     * Updates the label
     */
    public void updateVisited(int count) {
        this.visitedCount = count;
        setText("Visited: " + visitedCount);
    }
}
