package sh.solarsystem.view;

import javafx.scene.control.Label;

/**
 * Displays the speed multiplier
 */
public class SpeedLabel extends Label {

    private double currentMultiplier = 1.0;

    /**
     * Makes the default x1.0
     */
    public SpeedLabel() {
        super("Speed: x1.0");
        setLayoutX(10);
        setLayoutY(50);
        setStyle("-fx-text-fill: white;");
    }

    /**
     * Updates the speed label
     */
    public void updateSpeed(double newSpeed) {
        this.currentMultiplier = newSpeed;
        setText(String.format("Speed: x%.1f", currentMultiplier));
    }

    public double getCurrentMultiplier() {
        return currentMultiplier;
    }
}
