package sh.solarsystem.model;

import sh.solarsystem.factory.PlanetFactory;
import sh.solarsystem.factory.PlanetFactoryIF;

import java.util.ArrayList;
import java.util.List;

/**
 * Has all the planet data used in game
 */
public class SolarSystemModel {

    private final List<Planet> planetList;          
    private final PlanetFactoryIF planetFactory;  

    /**
     * Loads all 8 planets in the solar system
     */
    public SolarSystemModel() {
        this.planetFactory = new PlanetFactory();
        this.planetList = new ArrayList<>();

        String[] planetNames = {
            "Mercury", "Venus", "Earth", "Mars",
            "Jupiter", "Saturn", "Uranus", "Neptune"
        };

        for (String name : planetNames) {
            planetList.add(planetFactory.createPlanet(name));
        }
    }

    /**
     * Gets the list of all planets
     */
    public List<Planet> getPlanets() {
        return planetList;
    }
}
