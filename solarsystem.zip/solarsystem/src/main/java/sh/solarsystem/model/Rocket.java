package sh.solarsystem.model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * Makes the rocket class that moves around
 */
public class Rocket {

    private double x, y;
    private double velocityX = 0, velocityY = 0;
    private final double width = 10, height = 10;

    /**
     * Makes the rocket and adds it in the middle of the screen
     */
    public Rocket(int startX, int startY) {
        this.x = startX;
        this.y = startY;
    }

    public void setVelocityX(double vx) {
        this.velocityX = vx;
    }

    public void setVelocityY(double vy) {
        this.velocityY = vy;
    }

    /**
     * Moves the rocket 
     */
    public void update() {
        x += velocityX;
        y += velocityY;
    }

    public void render(GraphicsContext gc) {
        gc.setFill(Color.RED);
        gc.fillRect(x, y, width, height);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
}
